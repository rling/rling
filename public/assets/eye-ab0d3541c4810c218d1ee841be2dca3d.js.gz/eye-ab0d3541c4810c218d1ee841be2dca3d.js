/**
 *
 * Zoomimage
 * Author: Stefan Petre www.eyecon.ro
 * 
 */
(function(a){var b=window.EYE=function(){var b={init:[]};return{init:function(){a.each(b.init,function(a,b){b.call()})},extend:function(a){for(var b in a)a[b]!=undefined&&(this[b]=a[b])},register:function(a,c){b[c]||(b[c]=[]),b[c].push(a)}}}();a(b.init)})(jQuery)