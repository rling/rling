ActionMailer::Base.delivery_method = :smtp
ActionMailer::Base.smtp_settings = {
  :address => 'homie.mail.dreamhost.com',
  :port => 587,
  :domain => 'collegeaintcheap.com',
  :authentication => :login,
  :user_name => 'noah@collegeaintcheap.com',
  :password => 'truman'
}